﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DSS.Model
{
    public class MMenhDe
    {
        public int ID { get; set; }
        public String Name { get; set; }

    }
}
